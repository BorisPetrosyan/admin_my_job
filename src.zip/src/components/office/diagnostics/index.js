// import React from 'react'


// let Diagnostics = () => {
//     return (
//         <div>diagnostics</div>
//     )
// }

// export default Diagnostics;