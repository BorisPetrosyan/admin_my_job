// import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
// import React from 'react';
// import 'react-tabs/style/react-tabs.css';
// import CatalogRuTable from './catalog-ru';
// import CatalogEnTable from './catalog-en';


// let Catalog = () => {
//     return (
//         <div className="glossary__tabs">
//             <Tabs>
//                 <TabList>
//                     <Tab>Ru</Tab>
//                     <Tab>En</Tab>
//                 </TabList>

//                 <TabPanel>
//                     <CatalogRuTable />
//                 </TabPanel>
//                 <TabPanel>
//                     <CatalogEnTable />
//                 </TabPanel>
//             </Tabs>
//         </div>
//     )
// }

// export default Catalog;